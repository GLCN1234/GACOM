# GACOM FIX PATCH

## Issues fixed

| # | Problem | Fix |
|---|---------|-----|
| 1 | Store "Add" button visible to all users | Admin-only role check — only admin/super_admin see the + button |
| 2 | Store 400 errors from Supabase | Removed broken FK join; seller info fetched separately; demo products shown as fallback |
| 3 | Profile avatar hidden under banner color | Removed broken negative Transform.translate; avatar now in normal flow below banner |
| 4 | Wallet Paystack ERR_CONNECTION_TIMED_OUT | Removed wrong Bearer API call (requires secret key); now uses url_launcher to open Paystack checkout URL directly |
| 5 | Buttons invisible / stacked / not showing | All GacomButton in sheets now wrapped in `SizedBox(width: double.infinity)` with explicit height 54 |

## Apply in Codespace terminal

```bash
unzip gacom_fix_patch.zip -d _fix

BASE=_fix/gacom_fix_patch/lib

cp $BASE/features/store/screens/store_screen.dart   lib/features/store/screens/store_screen.dart
cp $BASE/features/wallet/screens/wallet_screen.dart lib/features/wallet/screens/wallet_screen.dart
cp $BASE/features/profile/screens/profile_screen.dart lib/features/profile/screens/profile_screen.dart

rm -rf _fix

git add lib/features/store/screens/store_screen.dart \
        lib/features/wallet/screens/wallet_screen.dart \
        lib/features/profile/screens/profile_screen.dart

git commit -m "fix: store admin-only, wallet paystack, profile avatar, button visibility"
git push
```
