# GACOM FULL UI PATCH

## What's included
| File | What changed |
|------|-------------|
| `lib/core/theme/app_theme.dart` | Full token system — GacomDecorations, borderOrange, all colors |
| `lib/features/home/screens/main_shell.dart` | 6-tab nav: Home, Compete, [+], Community, Wallet, **Profile** — glass blur, pulsing FAB |
| `lib/features/feed/screens/feed_screen.dart` | Greeting header (Image 1), pill search bar, trending strip, demo posts, animated like |
| `lib/features/profile/screens/profile_screen.dart` | Rank badge, achievement row, 3-tab (Posts/Clips/Stats), performance matrix, demo data |
| `lib/features/profile/screens/settings_screen.dart` | Grouped cards, verification card with perks, ads link, icon tiles, danger zone |
| `lib/features/ads/screens/ads_screen.dart` | Fixed — uses GacomDecorations.neonCard/glassCard correctly |
| `lib/shared/widgets/gacom_button.dart` | Gradient with glow shadow |

## Apply in Codespace terminal (from project root)

```bash
# Unzip
unzip gacom_full_patch.zip -d _patch

BASE=_patch/gacom_full_patch/lib

# Theme
cp $BASE/core/theme/app_theme.dart lib/core/theme/app_theme.dart

# Nav shell
cp $BASE/features/home/screens/main_shell.dart lib/features/home/screens/main_shell.dart

# Feed
cp $BASE/features/feed/screens/feed_screen.dart lib/features/feed/screens/feed_screen.dart

# Profile
cp $BASE/features/profile/screens/profile_screen.dart lib/features/profile/screens/profile_screen.dart

# Settings
cp $BASE/features/profile/screens/settings_screen.dart lib/features/profile/screens/settings_screen.dart

# Ads (build fix)
mkdir -p lib/features/ads/screens
cp $BASE/features/ads/screens/ads_screen.dart lib/features/ads/screens/ads_screen.dart

# Button
cp $BASE/shared/widgets/gacom_button.dart lib/shared/widgets/gacom_button.dart

# Cleanup
rm -rf _patch

# Commit
git add lib/core/theme/app_theme.dart \
        lib/features/home/screens/main_shell.dart \
        lib/features/feed/screens/feed_screen.dart \
        lib/features/profile/screens/profile_screen.dart \
        lib/features/profile/screens/settings_screen.dart \
        lib/features/ads/screens/ads_screen.dart \
        lib/shared/widgets/gacom_button.dart

git commit -m "feat: full UI overhaul — nav, feed, profile, settings, ads"
git push
```
