# GACOM UI OVERHAUL PATCH

## What this fixes + upgrades
1. **FIXES BUILD** — `lib/features/ads/screens/ads_screen.dart` is included and now uses only real theme tokens
2. **UPGRADES** `app_theme.dart` — adds `GacomDecorations` class and `GacomColors.borderOrange` that were missing
3. **UPGRADES** `main_shell.dart` — glassmorphic bottom nav with blur, pulsing create button, animated selection
4. **UPGRADES** `feed_screen.dart` — premium post cards, animated skeleton loaders, heart micro-interaction, editorial header
5. **UPGRADES** `gacom_button.dart` — gradient variant with glow shadow

## Apply in Codespace terminal (from project root)

```bash
# Unzip patch
unzip gacom_ui_overhaul.zip -d patch_ui

# 1. Theme (CRITICAL — fixes GacomDecorations and borderOrange)
cp patch_ui/gacom_ui_overhaul/lib/core/theme/app_theme.dart lib/core/theme/app_theme.dart

# 2. Bottom navigation shell
cp patch_ui/gacom_ui_overhaul/lib/features/home/screens/main_shell.dart lib/features/home/screens/main_shell.dart

# 3. Feed screen
cp patch_ui/gacom_ui_overhaul/lib/features/feed/screens/feed_screen.dart lib/features/feed/screens/feed_screen.dart

# 4. Ads screen (the build-breaking missing file)
mkdir -p lib/features/ads/screens
cp patch_ui/gacom_ui_overhaul/lib/features/ads/screens/ads_screen.dart lib/features/ads/screens/ads_screen.dart

# 5. Shared button
cp patch_ui/gacom_ui_overhaul/lib/shared/widgets/gacom_button.dart lib/shared/widgets/gacom_button.dart

# Cleanup
rm -rf patch_ui

# Commit and push
git add lib/core/theme/app_theme.dart \
        lib/features/home/screens/main_shell.dart \
        lib/features/feed/screens/feed_screen.dart \
        lib/features/ads/screens/ads_screen.dart \
        lib/shared/widgets/gacom_button.dart
git commit -m "feat: premium UI overhaul + fix missing ads_screen build error"
git push
```
