# GACOM ADS SCREEN PATCH

## Problem Fixed
Build error: `lib/features/ads/screens/ads_screen.dart` was missing from the project.
The router (`lib/core/services/router_service.dart`) imports it, but the file never existed in `lib/`.

## What's in this patch
- `lib/features/ads/screens/ads_screen.dart` — the missing AdsScreen widget

## How to apply (GitHub Codespace terminal)

Run these commands from the ROOT of your project (where `pubspec.yaml` is):

```bash
# 1. Create the directory if it doesn't exist
mkdir -p lib/features/ads/screens

# 2. Copy the file from the patch
cp gacom_ads_fix/lib/features/ads/screens/ads_screen.dart lib/features/ads/screens/ads_screen.dart

# 3. Verify it's there
ls lib/features/ads/screens/

# 4. Test build locally (optional)
flutter build web --no-wasm-dry-run
```

OR if you are applying the zip directly, unzip and copy:

```bash
unzip gacom_ads_fix.zip -d patch_tmp
mkdir -p lib/features/ads/screens
cp patch_tmp/lib/features/ads/screens/ads_screen.dart lib/features/ads/screens/ads_screen.dart
rm -rf patch_tmp
```

Then commit and push to trigger a new Netlify build.
